//
//  pdfCell.swift
//  SelfBriefingAPP
//
//  Created by AliSons  on 22/08/2019.
//  Copyright © 2019 AliSons . All rights reserved.
//

import Foundation
import UIKit

class pdfCell: UICollectionViewCell {

    
    @IBOutlet weak var pdfname: UILabel!
}
