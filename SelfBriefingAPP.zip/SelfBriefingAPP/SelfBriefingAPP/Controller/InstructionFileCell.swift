//
//  InstructionFileCell.swift
//  SelfBriefingAPP
//
//  Created by AliSons  on 17/08/2019.
//  Copyright © 2019 AliSons . All rights reserved.
//

import UIKit

class InstructionFileCell: UICollectionViewCell {
    @IBOutlet weak var Flag: UIImageView!
    @IBOutlet weak var InstructionDesc: UILabel!
    
    @IBOutlet weak var InstrucTitle: UILabel!
    @IBOutlet weak var Datetime: UILabel!
}
