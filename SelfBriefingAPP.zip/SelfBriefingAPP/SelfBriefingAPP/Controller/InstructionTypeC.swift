//
//  File.swift
//  
//
//  Created by AliSons  on 15/08/2019.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
    
    @IBOutlet weak var Name: UILabel!
    
}
