//
//  File.swift
//  SelfBriefingAPP
//
//  Created by AliSons  on 19/08/2019.
//  Copyright © 2019 AliSons . All rights reserved.
//


//MARK:- API URLS AND ENDPOINTS
let API_URL = "http://192.168.1.2:1234/haroon/atmrs_api/api/";
let API_URL2 = "http://192.168.1.2:1234/haroon/atmrs_api_new/api/";
let LOGIN_API = "Authentication/login"
let INSTRUCTION_API = "instructions/instructionsTypes"
let INSTRUCTION_GETBYID_API = "instructions/instructionsAllData/"
let MARKEDASREAD_API = "instructions/markedasRead/"
let SPECIALENTRIES_GETALL_API = "special_entry/allspecialentry/"


let X_API_KEY = "CODEX@123"
let API_USERNAME = "admin" as String
let API_PASSWORD = "1234" as String


//FileServer Address here
let FileServerPath = "http://192.168.1.12/development/PHP/Atlog-c/public/Files/"

