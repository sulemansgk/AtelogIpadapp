//
//  Request_API.swift
//  SelfBriefingAPP
//
//  Created by AliSons  on 21/08/2019.
//  Copyright © 2019 AliSons . All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON
class Requesting : NSObject {


}
